import subprocess

print("\033[33;1m jbatch / jb installed!\033[0m")


